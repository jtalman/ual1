#if !defined(DECPACKEDSYMBOLS)
#define DECPACKEDSYMBOLS

#ifdef IN_LIBGCC2
#define decPackedFromNumber __decPackedFromNumber
#define decPackedToNumber __decPackedToNumber
#endif

#endif
