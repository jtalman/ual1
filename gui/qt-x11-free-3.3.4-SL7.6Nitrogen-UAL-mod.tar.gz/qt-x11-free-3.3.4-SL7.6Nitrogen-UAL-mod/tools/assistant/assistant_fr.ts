<!DOCTYPE TS><TS>
<context>
    <name>Assistant</name>
    <message>
        <source>Welcome to the &lt;b&gt;Qt Assistant&lt;/b&gt;. Qt Assistant will give you quicker access to help and tips while using applications like Qt Designer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>FindDialog</name>
    <message encoding="UTF-8">
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Forwar&amp;d</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Case sensitive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpDialog</name>
    <message>
        <source>Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Con&amp;tents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Reference Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Designer Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Linguist Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>HelpDialogBase</name>
    <message encoding="UTF-8">
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Help&lt;/b&gt;&lt;p&gt;Choose the topic you need help for from the contents list, or search the index for keywords.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays help topics organized by category, index or bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Con&amp;tents</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Column 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Help topics organized by category.&lt;/b&gt;&lt;p&gt;Double-click an item to see which topics are in that category. To view a topic, select it, and then click &lt;b&gt;Display&lt;/b&gt;.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Look For:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter keyword</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter a keyword.&lt;/b&gt;&lt;p&gt;The list will select an item that matches the entered string best.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;List of available help topics.&lt;/b&gt;&lt;p&gt;Double-click on an item to open up the help page for this topic. You will have to choose the right page if more than one are found.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays the list of bookmarks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add the current displayed page as new bookmark to the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>D&amp;elete Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the selected bookmark from the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Preparing...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <source>Qt Assistant by Trolltech - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t load and display non-local file
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Link in New Window<byte value="x9"/>Shift+LMB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message encoding="UTF-8">
        <source>Qt Assistant by Trolltech</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Find in Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find in Text...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Qt Class Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Designer Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Zoom &amp;in</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Zoom &amp;out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Linguist Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>New Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>New Window...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Reference Documentation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>SettingsDialogBase</name>
    <message encoding="UTF-8">
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Link color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Underline links</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Fixed font:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TopicChooser</name>
    <message>
        <source>Choose a topic for &lt;b&gt;%1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>TopicChooserBase</name>
    <message encoding="UTF-8">
        <source>Choose Topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a topic from the list and click the &lt;b&gt;Display&lt;/b&gt;-button to open the online help.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Topics</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays a list of available help topics for the keyword.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Open the topic selected in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close the Dialog.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
