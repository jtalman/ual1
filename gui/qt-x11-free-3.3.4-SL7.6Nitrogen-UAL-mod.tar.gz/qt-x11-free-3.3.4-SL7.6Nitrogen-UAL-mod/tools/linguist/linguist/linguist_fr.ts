<!DOCTYPE TS><TS>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Qt Linguist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright (C) 2000-2002 Trolltech AS. All Rights Reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;This program is licensed to you under the terms of the GNU General Public License Version 2 as published by the Free Software Foundation. This gives you legal permission to copy, distribute and/or modify this software under certain conditions. For details, see the file &apos;LICENSE.GPL&apos; that came with this software distribution. If you did not get the file, send email to info@trolltech.com.&lt;/p&gt;
&lt;p&gt;The program is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorPage</name>
    <message>
        <source>Source text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindDialog</name>
    <comment>Choose Edit|Find from the menu bar or press Ctrl+F to pop up the Find dialog</comment>
    <message>
        <source>Fi&amp;nd what:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Match case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This window allows you to search and replace some text in the translations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace &amp;with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to replace the next occurrence of the text you typed in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to replace all occurrences of the text you typed in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This window allows you to search for some text in the translation source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Source texts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source texts are searched when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translations are searched when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments and contexts are searched when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type in the text to search for.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Texts such as &apos;TeX&apos; and &apos;tex&apos; are considered as different when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to find the next occurrence of the text you typed in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageEditor</name>
    <message>
        <source>bell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>backspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>new page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>new line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carriage return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phrases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phrases and guesses:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This whole panel allows you to view and edit the translation of some source text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This area shows the source text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This area shows a comment that may guide you, and the context in which the text occurs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is where you can enter or modify the translation of some source text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guess (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageCurl</name>
    <message>
        <source>Next unfinished phrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous unfinished phrase</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhraseBookBox</name>
    <comment>Go to Phrase &gt; Edit Phrase Book... The dialog that pops up is a PhraseBookBox.</comment>
    <message>
        <source>S&amp;ource phrase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Translation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Definition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Phrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove Phrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This window allows you to add, modify, or delete phrases in a phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the phrase in the source language.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the phrase in the target language corresponding to the source phrase.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a definition for the source phrase.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to add the phrase to the phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to remove the phrase from the phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to save the changes made.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot save phrase book &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhraseLV</name>
    <comment>The phrase list in the right panel of the main window (with Source phrase, Target phrase, and Definition in its header) is a PhraseLV object.</comment>
    <message>
        <source>(New Phrase)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a list of phrase entries relevant to the source text.  Each phrase is supplemented with a suggested translation and a definition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;u&gt;%1:&lt;/u&gt;&amp;nbsp;&amp;nbsp;%2&lt;/p&gt;&lt;p&gt;&lt;u&gt;%3:&lt;/u&gt;&amp;nbsp;&amp;nbsp;%4&lt;/p&gt;&lt;p&gt;&lt;u&gt;%5:&lt;/u&gt;&amp;nbsp;&amp;nbsp;%6&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source phrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Definition</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Qt Linguist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrWindow</name>
    <comment>This is the application&apos;s main window.</comment>
    <message>
        <source>Context</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MOD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This panel lists the source contexts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This panel lists the source texts. Items that violate validation rules are marked with a warning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 source phrase(s) loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot open &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt translation source (*.ts)
All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot save &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt message files for released applications (*.qm)
All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Context: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unresolved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>obsolete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing... (page %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search wrapped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot find the string &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt phrase books (*.qph)
All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create New Phrase Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A file called &apos;%1&apos; already exists.  Please choose another name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phrase book created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 phrase(s) loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 - %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to save &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Linguist by Trolltech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No phrase to translate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No untranslated phrases left.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;alidation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Phrases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Release...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re&amp;cently opened files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Find...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Replace...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Prev Unfinished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next Unfinished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;rev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ne&amp;xt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done and &amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Begin from Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Phrase Book...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open Phrase Book...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close Phrase Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Phrase Book...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print Phrase Book...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Accelerators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ending Punctuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Phrase Matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Revert Sorting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Display guesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;What&apos;s This?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a Qt translation source file (TS file) for editing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes made to this Qt translation source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes made to this Qt translationsource file into a new file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a Qt message file suitable for released applications from the current message file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print a list of all the phrases in the current Qt translation source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close this window and exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo the last editing operation performed on the translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo an undone editing operation performed on the translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard and deletes it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste the clipboard text into the translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the whole translation text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for some text in the translation source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue the search where it was left.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for some text in the translation source file and replace it by another text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a phrase book to assist translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle validity checks of accelerators.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle validity checks of ending punctuation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle checking that phrase suggestions are used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort the items back in the same order as in the message file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set whether or not to display translation guesses.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display the manual for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display information about %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display information about the Qt toolkit by Trolltech.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter What&apos;s This? mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copies the source text into the translation field.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moves to the next item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moves to the previous item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moves to the next unfinished item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moves to the previous unfinished item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Marks this item as done and moves to the next unfinished item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Phrase Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prev Unfinished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Unfinished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done and Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accelerators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Punctuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phrases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot read from phrase book &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close this phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow you to add, modify, or delete phrases of this phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print the entries of the phrase book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot create phrase book &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accelerator possibly superfluous in translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accelerator possibly missing in translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation does not end with the same punctuation as the source text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A phrase book suggestion for &apos;%1&apos; was ignored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
