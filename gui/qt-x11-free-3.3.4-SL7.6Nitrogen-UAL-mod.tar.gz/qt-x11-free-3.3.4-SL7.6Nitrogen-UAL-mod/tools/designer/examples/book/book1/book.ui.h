void BookForm::primeInsertAuthor( QSqlRecord * )
{

}

