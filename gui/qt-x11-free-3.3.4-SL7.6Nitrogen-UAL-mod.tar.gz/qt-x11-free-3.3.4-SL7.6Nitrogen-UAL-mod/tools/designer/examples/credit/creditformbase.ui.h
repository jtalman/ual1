void CreditFormBase::setAmount()
{

}

