// @(#)root/base:$Name:  $:$Id: InitGui.cxx,v 1.1.1.1 2000/05/16 17:00:39 rdm Exp $
// Author: Fons Rademakers   15/01/98

//______________________________________________________________________________
void InitGui()
{
   // Initialize the GUI and windowing system interface.
   // This version initializes the ROOT native GUI system.

   // Dummy for backward compatability.
   // Loading of libraries and initialization of graphics objects is
   // done in TApplication::LoadGraphicsLibs().
}

