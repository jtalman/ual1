#ifndef AFTERBASE_H_HEADER_INCLUDED
#define AFTERBASE_H_HEADER_INCLUDED

#define HAVE_AFTERBASE_FLAG 0


# include "../asim_afterbase.h"

#define R_OK 04

#endif /* AFTERBASE_H_HEADER_INCLUDED */

